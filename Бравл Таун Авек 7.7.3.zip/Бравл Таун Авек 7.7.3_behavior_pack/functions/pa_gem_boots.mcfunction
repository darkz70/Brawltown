replaceitem entity @s slot.armor.feet 1 pa:gem_boots
replaceitem entity @s slot.weapon.mainhand 0 air