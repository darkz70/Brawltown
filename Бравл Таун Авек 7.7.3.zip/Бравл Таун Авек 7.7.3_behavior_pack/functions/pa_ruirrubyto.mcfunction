give @s pa:ruirrubyto
