give @s pa:mixed
