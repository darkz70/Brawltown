give @s pa:spkkingot
