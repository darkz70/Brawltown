give @s pa:coincoirfear
