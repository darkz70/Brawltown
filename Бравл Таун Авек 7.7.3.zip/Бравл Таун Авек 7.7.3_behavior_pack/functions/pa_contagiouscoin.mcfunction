give @s pa:contagiouscoin
