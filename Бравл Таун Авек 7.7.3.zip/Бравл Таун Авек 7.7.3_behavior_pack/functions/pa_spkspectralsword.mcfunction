give @s pa:spkspectralsword
