give @s pa:energy
