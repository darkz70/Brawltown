give @s pa:chro
