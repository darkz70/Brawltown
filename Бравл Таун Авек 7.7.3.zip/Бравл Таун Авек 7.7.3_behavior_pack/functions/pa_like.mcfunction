give @s pa:like
