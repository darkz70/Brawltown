give @s pa:cartoonsword
